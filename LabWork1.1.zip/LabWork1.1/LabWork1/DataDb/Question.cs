﻿using System;
using System.Collections.Generic;

namespace LabWork1.DataDb;

public partial class Question
{
    public int Id { get; set; }

    public string Text { get; set; } = null!;

    public virtual ICollection<Answer> Answers { get; set; } = new List<Answer>();

    public virtual ICollection<Lecture> Lectures { get; set; } = new List<Lecture>();
}
