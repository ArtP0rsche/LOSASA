﻿using System;
using System.Collections.Generic;

namespace LabWork1.Models;

public partial class Model
{
    public int Id { get; set; }

    public string Title { get; set; } = null!;

    public virtual ICollection<Lecture> Lectures { get; set; } = new List<Lecture>();
}
