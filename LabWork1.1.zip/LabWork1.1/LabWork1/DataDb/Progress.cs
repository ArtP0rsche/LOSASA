﻿using System;
using System.Collections.Generic;

namespace LabWork1.DataDb;

public partial class Progress
{
    public int Id { get; set; }

    public sbyte? Persentage { get; set; }

    public int UsersId { get; set; }

    public virtual User Users { get; set; } = null!;
}
