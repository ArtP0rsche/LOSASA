﻿using CommunityToolkit.Mvvm.ComponentModel;
using LabWork1.DataDb;
using LabWork1.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabWork1.ViewModels
{
    public partial class CatalogViewModel : ObservableObject
    {
        private ModelService _modelService = new();
        private LectureService _lectureService = new();

        [ObservableProperty]
        private ObservableCollection<Model> _models = new();

        [ObservableProperty]
        private ObservableCollection<Lecture> _lectures = new();

        [ObservableProperty]
        private Model _selectedModel;

        public CatalogViewModel()
        {
            Load();
        }

        private async Task Load()
        {
            Models = [..await _modelService.GetModelsAsync()];
            SelectedModel = Models[0];
        }
    }
}
