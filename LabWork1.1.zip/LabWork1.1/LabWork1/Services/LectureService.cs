﻿using LabWork1.DataDb;
using LabWork1.DbContextDir;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabWork1.Services
{
    public class LectureService
    {
        private LecturesDbContext _context = new();

        public async Task<List<Lecture>> GetLecturesAsync()
        {
            return await _context.Lectures.ToListAsync();
        }
    }
}
