﻿using System;
using System.Collections.Generic;

namespace LabWork1.Models;

public partial class User
{
    public int Id { get; set; }

    public string Login { get; set; } = null!;

    public string PasswordHash { get; set; } = null!;

    public int RolesId { get; set; }

    public virtual ICollection<Progress> Progresses { get; set; } = new List<Progress>();

    public virtual Role Roles { get; set; } = null!;
}
