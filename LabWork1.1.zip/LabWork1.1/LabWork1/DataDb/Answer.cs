﻿using System;
using System.Collections.Generic;

namespace LabWork1.DataDb;

public partial class Answer
{
    public int Id { get; set; }

    public string Text { get; set; } = null!;

    public sbyte IsCorrect { get; set; }

    public int QuestionsId { get; set; }

    public virtual Question Questions { get; set; } = null!;
}
