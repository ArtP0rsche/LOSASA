﻿using System;
using System.Collections.Generic;
using LabWork1.DataDb;
using Microsoft.EntityFrameworkCore;
using Pomelo.EntityFrameworkCore.MySql.Scaffolding.Internal;

namespace LabWork1.DbContextDir;

public partial class LecturesDbContext : DbContext
{
    public LecturesDbContext()
    {
    }

    public LecturesDbContext(DbContextOptions<LecturesDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Answer> Answers { get; set; }

    public virtual DbSet<Lecture> Lectures { get; set; }

    public virtual DbSet<Model> Models { get; set; }

    public virtual DbSet<Progress> Progresses { get; set; }

    public virtual DbSet<Question> Questions { get; set; }

    public virtual DbSet<Role> Roles { get; set; }

    public virtual DbSet<User> Users { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseMySql("server=mysql;database=ispp2114;user=ispp2114;password=2114", Microsoft.EntityFrameworkCore.ServerVersion.Parse("8.0.39-mysql"));

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder
            .UseCollation("utf8mb4_0900_ai_ci")
            .HasCharSet("utf8mb4");

        modelBuilder.Entity<Answer>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("answers");

            entity.HasIndex(e => e.QuestionsId, "fk_answers_questions_idx");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.IsCorrect).HasColumnName("is_correct");
            entity.Property(e => e.QuestionsId).HasColumnName("questions_id");
            entity.Property(e => e.Text)
                .HasMaxLength(255)
                .HasColumnName("text");

            entity.HasOne(d => d.Questions).WithMany(p => p.Answers)
                .HasForeignKey(d => d.QuestionsId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_answers_questions");
        });

        modelBuilder.Entity<Lecture>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("lectures");

            entity.HasIndex(e => e.ModelsId, "fk_lectures_models1_idx");

            entity.HasIndex(e => e.QuestionsId, "fk_lectures_questions1_idx");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.AudioPath)
                .HasMaxLength(255)
                .HasColumnName("audio_path");
            entity.Property(e => e.ModelsId).HasColumnName("models_id");
            entity.Property(e => e.QuestionsId).HasColumnName("questions_id");
            entity.Property(e => e.Text).HasColumnName("text");
            entity.Property(e => e.Title)
                .HasMaxLength(100)
                .HasColumnName("title");
            entity.Property(e => e.VideoPath)
                .HasMaxLength(255)
                .HasColumnName("video_path");

            entity.HasOne(d => d.Models).WithMany(p => p.Lectures)
                .HasForeignKey(d => d.ModelsId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_lectures_models1");

            entity.HasOne(d => d.Questions).WithMany(p => p.Lectures)
                .HasForeignKey(d => d.QuestionsId)
                .HasConstraintName("fk_lectures_questions1");
        });

        modelBuilder.Entity<Model>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("models");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Title)
                .HasMaxLength(100)
                .HasColumnName("title");
        });

        modelBuilder.Entity<Progress>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("progress");

            entity.HasIndex(e => e.UsersId, "fk_progress_users1_idx");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Persentage)
                .HasDefaultValueSql("'0'")
                .HasColumnName("persentage");
            entity.Property(e => e.UsersId).HasColumnName("users_id");

            entity.HasOne(d => d.Users).WithMany(p => p.Progresses)
                .HasForeignKey(d => d.UsersId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_progress_users1");
        });

        modelBuilder.Entity<Question>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("questions");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Text)
                .HasMaxLength(255)
                .HasColumnName("text");
        });

        modelBuilder.Entity<Role>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("roles");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Name)
                .HasMaxLength(45)
                .HasColumnName("name");
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("users");

            entity.HasIndex(e => e.RolesId, "fk_users_roles1_idx");

            entity.HasIndex(e => e.Login, "login_UNIQUE").IsUnique();

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Login)
                .HasMaxLength(150)
                .HasColumnName("login");
            entity.Property(e => e.PasswordHash)
                .HasMaxLength(255)
                .HasColumnName("password_hash");
            entity.Property(e => e.RolesId).HasColumnName("roles_id");

            entity.HasOne(d => d.Roles).WithMany(p => p.Users)
                .HasForeignKey(d => d.RolesId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_users_roles1");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
