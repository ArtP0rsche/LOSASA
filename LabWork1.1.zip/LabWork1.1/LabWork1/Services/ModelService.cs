﻿using LabWork1.DataDb;
using LabWork1.DbContextDir;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabWork1.Services
{
    public class ModelService
    {
        private LecturesDbContext _context = new();

        public async Task<List<Model>> GetModelsAsync()
        {
            return await _context.Models.Include(m=>m.Lectures).ToListAsync();
        }
    }
}
