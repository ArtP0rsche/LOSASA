﻿using System;
using System.Collections.Generic;

namespace LabWork1.Models;

public partial class Partner
{
    public int? Id { get; set; }

    public string? Name { get; set; }

    public int? DirectorId { get; set; }

    public long? PhoneNumber { get; set; }

    public int? Index { get; set; }

    public int? CityId { get; set; }

    public string? Address { get; set; }

    public int? IdType { get; set; }
}
