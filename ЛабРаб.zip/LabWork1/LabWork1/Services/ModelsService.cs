﻿using LabWork1.DbContextDir;
using LabWork1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabWork1.Services
{
    class ModelsService
    {
        private Ispp2114Context _context = new();

    }
}
