﻿using System;
using System.Collections.Generic;

namespace LabWork1.DataDb;

public partial class Lecture
{
    public int Id { get; set; }

    public string? Text { get; set; }

    public string? VideoPath { get; set; }

    public string? AudioPath { get; set; }

    public string Title { get; set; } = null!;

    public int ModelsId { get; set; }

    public int? QuestionsId { get; set; }

    public virtual Model Models { get; set; } = null!;

    public virtual Question? Questions { get; set; }
}
